module.exports={
    userController: require('./userController'),
    petController: require('./petController'),
    recordController: require('./recordController'),
    taskController: require('./taskController')
   }
   