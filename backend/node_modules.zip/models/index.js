'use strict'
module.exports = {
    Users: require('./userModel'),
    Pets: require('./petModel'),
    Records: require('./recordModel'),
    Tasks: require('./taskModel'),
   
    
};
