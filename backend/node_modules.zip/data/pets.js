const pets= [
    {"_id":"1","name":"pie","email":"lifeof@user.com","password":"everest","createdAt":"2023-02-26T07:01:59.435Z","updatedAt":"2023-02-26T07:01:59.435Z","__v":0},
    {"_id":"63fb03fc92bff4cd3843a477","name":"otto","email":"bigbubbles@user.com","password":"skippy","createdAt":"2023-02-26T07:02:20.760Z","updatedAt":"2023-02-26T07:02:20.760Z","__v":0},
    {"_id":"63fbd83183ddbf9d405967a3","name":"tato","email":"penny@user.com","password":"naughty123","createdAt":"2023-02-26T22:07:45.786Z","updatedAt":"2023-02-26T22:07:45.786Z","__v":0},
    {"_id":"63fbdceeb9df8dea4a35a419","name":"jane","email":"d@user.com","password":"pad123","createdAt":"2023-02-26T22:27:58.471Z","updatedAt":"2023-02-26T22:27:58.471Z","__v":0},
    {"_id":"63fbdd849f26b7877077355f","name":"oyster r","email":"oi@user.com","password":"polly123","createdAt":"2023-02-26T22:30:28.963Z","updatedAt":"2023-02-26T22:30:28.963Z","__v":0}
]

module.exports = pets;